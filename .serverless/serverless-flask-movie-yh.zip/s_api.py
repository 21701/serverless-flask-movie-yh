import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='woosss',
    application_name='serverless-flask-movie-yh',
    app_uid='sWdp9xFvQLnRnvFp6p',
    org_uid='f8cb1e03-adb7-48ac-a0b9-3fff974d2fed',
    deployment_uid='98cee05d-e4c5-4476-a5e7-c6630d02d9da',
    service_name='serverless-flask-movie-yh',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='5.5.3',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'serverless-flask-movie-yh-dev-api', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('wsgi_handler.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
